const axios = require("axios");

export default function sendMail(data) {

  let htmlcode;

  if (data.indate) {
    var t1 = data.indate.split("-");
    data.indate = t1[2] + "-" + t1[1] + "-" + t1[0];
  }

  if (data.outdate) {
    var t2 = data.outdate.split("-");
    data.outdate = t2[2] + "-" + t2[1] + "-" + t2[0];
  }

  if (data.intime) {
    var itm = data.intime.split(":");
    if (parseInt(itm[0]) >= 12) {
      if (itm[0] !== "12") itm[0] = itm[0] - 12;
      data.intime = itm[0] + ":" + itm[1] + " pm";
    } else {
      data.intime = data.intime + " am";
    }
  }

  if (data.action === "Room Booking") {
    htmlcode = ` <tr>
                              <td style="text-align:justify;width:20%;">Name :</td>
                              <td style="text-align:justify;width:80%;">${data.name}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Phone :</td>
                              <td style="text-align:justify;width:80%;">${data.phone}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Email :</td>
                              <td style="text-align:justify;width:80%;">${data.email}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Property :</td>
                              <td style="text-align:justify;width:80%;">${data.hotel}, ${data.hotel_city} - ${data.venue}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">No.of Rooms :</td>
                              <td style="text-align:justify;width:80%;">${data.norooms}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Persons :</td>
                              <td style="text-align:justify;width:80%;">${data.adults} Adults ${data.children} Kids</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Check-In :</td>
                              <td style="text-align:justify;width:80%;">${data.indate}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Check-Out :</td>
                              <td style="text-align:justify;width:80%;">${data.outdate}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Guest's City :</td>
                              <td style="text-align:justify;width:80%;">${data.city}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Details :</td>
                              <td style="text-align:justify;width:80%;">${data.msg}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Message Time:</td>
                              <td style="text-align:justify;width:80%;">${data.date} - ${data.time}</td>
                          </tr>`;
  } else if (
    ["Dining", "Banquet", "Package Enquiry"].includes(
      data.action
    )
  ) {
    htmlcode = ` <tr>
    <td style="text-align:justify;width:20%;">Name :</td>
    <td style="text-align:justify;width:80%;">${data.name}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Phone :</td>
    <td style="text-align:justify;width:80%;">${data.phone}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Email :</td>
    <td style="text-align:justify;width:80%;">${data.email}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Property :</td>
    <td style="text-align:justify;width:80%;">${data.hotel}, ${data.hotel_city}</td>
</tr>
`;
    if (data.action !== "Package Enquiry") {
      htmlcode += `
  <tr>
    <td style="text-align:justify;width:20%;">Venue :</td>
    <td style="text-align:justify;width:80%;">${data.venue}</td>
</tr>`;
    }

    htmlcode += `
<tr>
    <td style="text-align:justify;width:20%;">No.of Persons :</td>
    <td style="text-align:justify;width:80%;">${data.capacity}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Check-In :</td>
    <td style="text-align:justify;width:80%;">${data.indate} ${data.intime}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Guest's City :</td>
    <td style="text-align:justify;width:80%;">${data.city}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Details :</td>
    <td style="text-align:justify;width:80%;">${data.msg}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Message Time:</td>
    <td style="text-align:justify;width:80%;">${data.date} - ${data.time}</td>
</tr>`;
  } else if (["Submit Feedback", "Register Complaint"].includes(data.action)) {
    htmlcode = `  <tr>
                              <td style="text-align:justify;width:20%;">Name :</td>
                              <td style="text-align:justify;width:80%;">${data.name}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Phone :</td>
                              <td style="text-align:justify;width:80%;">${data.phone}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Email :</td>
                              <td style="text-align:justify;width:80%;">${data.email}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Guest's City :</td>
                              <td style="text-align:justify;width:80%;">${data.city}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Property :</td>
                              <td style="text-align:justify;width:80%;">${data.hotel}, ${data.hotel_city}</td>
                          </tr>
                          
                          <tr>
                              <td style="text-align:justify;width:20%;">Details :</td>
                              <td style="text-align:justify;width:80%;">${data.msg}</td>
                          </tr>
                          <tr>
                              <td style="text-align:justify;width:20%;">Message Time:</td>
                              <td style="text-align:justify;width:80%;">${data.date} - ${data.time}</td>
                          </tr>`;
  } else if (data.action === "General Enquiry") {
    htmlcode = ` <tr>
    <td style="text-align:justify;width:20%;">Name :</td>
    <td style="text-align:justify;width:80%;">${data.name}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Phone :</td>
    <td style="text-align:justify;width:80%;">${data.phone}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Email :</td>
    <td style="text-align:justify;width:80%;">${data.email}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Guest's City :</td>
    <td style="text-align:justify;width:80%;">${data.city}</td>
</tr>
<tr>
                              <td style="text-align:justify;width:20%;">Property :</td>
                              <td style="text-align:justify;width:80%;">${data.hotel}, ${data.hotel_city}</td>
                          </tr>
<tr>
    <td style="text-align:justify;width:20%;">Query :</td>
    <td style="text-align:justify;width:80%;">${data.msg}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Status :</td>
    <td style="text-align:justify;width:80%;">${data.status}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Answer Given :</td>
    <td style="text-align:justify;width:80%;">${data.reply}</td>
</tr>
<tr>
    <td style="text-align:justify;width:20%;">Message Time:</td>
    <td style="text-align:justify;width:80%;">${data.date} - ${data.time}</td>
</tr>`;
  }

  data.code = {
    htmlcode: htmlcode,
    logo: "https://poppyshotels.com/assets/images/hotels/tuskers-hill-by-poppys-anaikatti/logo/tuskers-hill-logo.jpg",
    alt: "tuskers Bot",
    txt1: "Attention tuskers Team,",
    txt2: `A customer has just submitted a - ${data.action} - action through the bot. The details are as follows.`,
    txt3: "",
    headercolor: "#ba2429",
    footercolor: "#dbdbdb",
    declaration: "tuskers Bot",
    footer:
      "tuskers Hotels ©" + new Date().getFullYear() + ". All rights reserved.",
  };

  data.mailparams = {
    from: "tuskers Bot",
    to: "bookings@poppyshotels.com",
    subject: "Website Bot Notification - " + data.action,
  };

  axios
    .post("https://cheersbyemailer.herokuapp.com/universal", {
      data: data,
    })
    .then(function(response) {
      //console.log("axios response", response);
    })
    .catch(function(error) {
      //console.log(error);
    });
}
