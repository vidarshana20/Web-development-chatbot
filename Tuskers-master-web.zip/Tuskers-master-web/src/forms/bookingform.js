import React from "react";
import "../styles/custom.css";

class BookingForm extends React.Component {
  constructor(props) {
    super(props);

    //console.log("Booking Form Props constructor", props);

    var indate = props.step.component._owner.memoizedState.indate;
    var outdate = props.step.component._owner.memoizedState.outdate;
    var norooms = props.step.component._owner.memoizedState.norooms;
    var adults = props.step.component._owner.memoizedState.adults;
    var children = props.step.component._owner.memoizedState.children;
    var venue = props.step.component._owner.memoizedState.venue;
    var hotel = props.step.component._owner.memoizedState.hotel;
    var action = props.step.component._owner.memoizedState.action;

    if (props.data) {
      action = props.data.action;
      venue = props.data.venue;
    }

    this.state = {
      indate: indate,
      outdate: outdate,
      norooms: norooms,
      adults: adults,
      children: children,
      venue: venue,
      hotel: hotel,
      action: action,
    };

    //console.log("BOOK STATE: ", this.state);

    this.handleEvent = this.handleEvent.bind(this);
  }

  handleEvent(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  validateDate(input, double = false) {
    let curr;
    input = new Date(
      new Date(input).toLocaleString("en-US", {
        timeZone: "Asia/Kolkata",
      })
    );

    if (double) {
      curr = new Date(
        new Date(double).toLocaleString("en-US", {
          timeZone: "Asia/Kolkata",
        })
      );
    } else {
      curr = new Date(
        new Date().toLocaleString("en-US", {
          timeZone: "Asia/Kolkata",
        })
      );
    }
    //console.log("Current/Out: ", curr.getTime());
    //console.log("Input: ", input.getTime());

    return curr <= new Date(input)
      ? {
          success: true,
          date: input,
        }
      : {
          success: false,
          message: !double
            ? `You cannot check-in for a past date. Try Again`
            : "Check-out cannot be earlier than check-in. Try again",
        };
  }

  Submitinfo() {
    let result1,
      result2,
      flag = true;

    if (!this.state.indate) {
      alert("Check-in date cannot be empty. Try again and Submit.");
      flag = false;
    }

    if (!this.state.norooms) {
      alert("No.of Rooms cannot be empty. Try again and Submit.");
      flag = false;
    }

    if (!this.state.adults) {
      alert("No.of Adults cannot be empty. Try again and Submit.");
      flag = false;
    }

    if (!this.state.children) {
      alert("No.of children cannot be empty. Try again and Submit.");
      flag = false;
    }

    if (
      this.state.children < 0 ||
      this.state.adults < 0 ||
      this.state.norooms < 0
    ) {
      alert(
        "The number of rooms/adults/children cannot be less than 0. Try again."
      );
      flag = false;
    }

    if (this.state.indate) {
      result1 = this.validateDate(this.state.indate);
      if (result1.success && flag) {
        //console.log("Service Form Two final state- ", this.state);

        result2 = this.validateDate(this.state.outdate, this.state.indate);

        if (result2.success) {
          this.setState({ trigger: true }, () => {
            this.props.triggerNextStep({
              trigger: "confirm-booking-details",
              value: this.state,
            });
          });
        } else {
          alert(result2.message);
        }
      } else {
        if (this.state.indate && result1.message) alert(result1.message);
      }
    }
  }

  showMenu() {
    this.setState({ trigger: true }, () => {
      this.props.triggerNextStep({
        trigger: "mainmenu",
        value: this.state,
      });
    });
  }

  render() {
    //console.log("Contact Form - Props: ", this.props);

    const ac_textblock = {
      overflow: "hidden",
      fontFamily: "Helvetica, sans-serif",
      fontSize: "14px",
      color: "rgba(51, 51, 51, 0.933)",
      fontWeight: 400,
      textAlign: "left",
      lineHeight: "18.62px",
      overflowWrap: "break-word",
      boxSizing: "border-box",
      flex: "0 0 auto",
    };
    const p_style = { marginTop: "0px", width: "100%", marginBottom: "0px" };
    const ac_horizontal_separator = {
      height: "8px",
      overflow: "hidden",
      marginRight: "0px",
      marginLeft: "0px",
      flex: "0 0 auto",
    };
    const ac_horizontal_separator2 = {
      height: "8px",
      overflow: "hidden",
      display: "flex",
      marginRight: "0px",
      marginLeft: "0px",
      flex: "0 0 auto",
    };
    const div_style = {
      display: "flex",
      flexDirection: "column",
      boxSizing: "border-box",
      flex: "0 0 auto",
    };
    const input_style = {
      flex: "1 1 auto",
      minWidth: "0px",
      borderRadius: "8px",
    };

    const ac_container = {
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-start",
      boxSizing: "border-box",
      flex: "0 0 auto",
      padding: "15px",
      margin: "0px",
      width: "auto",
    };

    const ac_columnset = {
      display: "flex",
      justifyContent: "flex-start",
      boxSizing: "border-box",
      flex: "0 0 auto",
      padding: "0px",
      margin: "0px",
    };

    return (
      <div aria-hidden="false" className="attachment">
        <div
          className="card bookroom"
          style={{
            background: "rgb(233, 234, 234)",
            borderRadius: "25px",
            width: "300px",
          }}
        >
          <div className="ac-container" tabIndex={0} style={ac_container}>
            <div className="ac-columnSet" style={ac_columnset}>
              <div
                className="ac-container"
                style={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "flex-start",
                  boxSizing: "border-box",
                  minWidth: "0px",
                  flex: "1 1 100%",
                  padding: "0px",
                  margin: "0px",
                }}
              >
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>
                    Check-in Date
                    <span className="mandatory-field">*</span>
                  </p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <input
                      type="date"
                      name="indate"
                      min={new Date().toISOString().split("T")[0]}
                      max="undefined"
                      onChange={this.handleEvent}
                      className="ac-input ac-dateInput input-bot fontFamilyBot"
                      defaultValue={this.state.indate}
                      tabIndex={0}
                      style={{
                        width: "100%",
                        minWidth: "0px",
                        borderRadius: "8px",
                      }}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>
                    Check-out Date <span className="mandatory-field">*</span>
                  </p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <input
                      type="date"
                      name="outdate"
                      min={this.state.indate}
                      max="undefined"
                      onChange={this.handleEvent}
                      className="ac-input ac-dateInput input-bot fontFamilyBot"
                      defaultValue={this.state.outdate}
                      tabIndex={0}
                      style={{
                        width: "100%",
                        minWidth: "0px",
                        borderRadius: "8px",
                      }}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />

                <div className="custom-main-div">
                  <div className="custom-row left">
                    <div className="ac-textBlock" style={ac_textblock}>
                      <p style={p_style}>
                        Rooms
                        <span className="mandatory-field">
                          *<br></br>
                        </span>
                      </p>
                    </div>
                    <div
                      className="ac-horizontal-separator"
                      style={ac_horizontal_separator2}
                    />
                    <div style={div_style}>
                      <div
                        className="ac-input-container"
                        style={{ display: "flex" }}
                      >
                        <input
                          type="number"
                          name="norooms"
                          onChange={this.handleEvent}
                          className="ac-input ac-textInput"
                          defaultValue={this.state.norooms}
                          tabIndex={0}
                          min="0"
                          style={input_style}
                        />
                      </div>

                      <div
                        className="ac-horizontal-separator"
                        style={ac_horizontal_separator}
                      />
                    </div>
                  </div>

                  <div className="custom-row middle">
                    <div className="ac-textBlock" style={ac_textblock}>
                      <p style={p_style}>
                        Adults(12+)
                        <span className="mandatory-field">*</span>
                      </p>
                    </div>
                    <div
                      className="ac-horizontal-separator"
                      style={ac_horizontal_separator2}
                    />
                    <div style={div_style}>
                      <div
                        className="ac-input-container"
                        style={{ display: "flex" }}
                      >
                        <input
                          type="number"
                          name="adults"
                          min="0"
                          onChange={this.handleEvent}
                          className="ac-input ac-textInput"
                          defaultValue={this.state.adults}
                          tabIndex={0}
                          style={input_style}
                        />
                      </div>
                    </div>

                    <div
                      className="ac-horizontal-separator"
                      style={ac_horizontal_separator}
                    />
                  </div>

                  <div className="custom-row right">
                    <div className="ac-textBlock" style={ac_textblock}>
                      <p style={p_style}>
                        Children
                        <span className="mandatory-field">*</span>
                      </p>
                    </div>
                    <div
                      className="ac-horizontal-separator"
                      style={ac_horizontal_separator2}
                    />
                    <div style={div_style}>
                      <div
                        className="ac-input-container"
                        style={{ display: "flex" }}
                      >
                        <input
                          type="number"
                          name="children"
                          min="0"
                          onChange={this.handleEvent}
                          className="ac-input ac-textInput"
                          defaultValue={this.state.children}
                          tabIndex={0}
                          style={input_style}
                        />
                      </div>
                    </div>
                  </div>

                  <div
                    className="ac-horizontal-separator"
                    style={ac_horizontal_separator}
                  />
                </div>

                <div style={{ overflow: "hidden" }}>
                  <button
                    id="submitbutton"
                    aria-label="Submit Info"
                    type="button"
                    onClick={() => {
                      this.Submitinfo();
                    }}
                    className="submitbtn follow"
                  >
                    Submit
                  </button>

                  <button
                    id="menubutton"
                    aria-label="Main Menu"
                    type="button"
                    onClick={() => this.showMenu()}
                    className="submitbtn follow"
                  >
                    Back to Menu
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default BookingForm;
