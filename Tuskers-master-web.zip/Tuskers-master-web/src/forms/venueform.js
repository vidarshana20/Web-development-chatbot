import React from "react";
import "../styles/custom.css";

class VenueForm extends React.Component {
  constructor(props) {
    super(props);

    var indate = props.step.component._owner.memoizedState.indate;
    var intime = props.step.component._owner.memoizedState.intime;
    var capacity = props.step.component._owner.memoizedState.capacity;
    var venue = props.step.component._owner.memoizedState.venue;
    var hotel = props.step.component._owner.memoizedState.hotel;
    var action = props.step.component._owner.memoizedState.action;

    if (props.data) {
      action = props.data.action;
      venue = props.data.venue;
    }

    this.state = {
      indate: indate,
      intime: intime,
      capacity: capacity,
      hotel: hotel,
      venue: venue,
      action: action,
    };

    //console.log("Venue Form state", this.state);

    this.handleEvent = this.handleEvent.bind(this);
  }

  handleEvent(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  validateDate(input) {
    var curr = new Date(
      new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata" })
    );
    input = new Date(
      new Date(input).toLocaleString("en-US", {
        timeZone: "Asia/Kolkata",
      })
    );
    //console.log("Current: ", new Date(curr.getTime()));
    //console.log("Input: ", new Date(input.getTime()));

    return curr <= new Date(input)
      ? {
          success: true,
          date: input,
        }
      : {
          success: false,
          message: `You cannot check-in for a past date. Try Again`,
        };
  }

  Submitinfo() {
    let result,
      flag = true;
    if (!this.state.indate) {
      flag = false;
      alert("Check-in date cannot be empty. Try again and Submit.");
    }

    if (!this.state.intime) {
      flag = false;
      alert("Check-in time cannot be empty. Try again and Submit.");
    }

    if (!this.state.capacity) {
      flag = false;
      alert("No.of Attendees cannot be empty. Try again and Submit.");
    }

    if (this.state.indate) {
      result = this.validateDate(this.state.indate + " " + this.state.intime);
      if (result.success && flag) {
        this.setState({ trigger: true }, () => {
          this.props.triggerNextStep({
            trigger: "confirm-venue-details",
            value: this.state,
          });
        });
      } else {
        if (this.state.indate && result.message) alert(result.message);
      }
    }
  }

  showMenu() {
    this.setState({ trigger: true }, () => {
      this.props.triggerNextStep({
        trigger: "mainmenu",
        value: this.state,
      });
    });
  }

  render() {
    //console.log("Venue Form - State: ", this.state);

    const ac_textblock = {
      overflow: "hidden",
      fontFamily: "Helvetica, sans-serif",
      fontSize: "14px",
      color: "rgba(51, 51, 51, 0.933)",
      fontWeight: 400,
      textAlign: "left",
      lineHeight: "18.62px",
      overflowWrap: "break-word",
      boxSizing: "border-box",
      flex: "0 0 auto",
    };
    const p_style = { marginTop: "0px", width: "100%", marginBottom: "0px" };
    const ac_horizontal_separator = {
      height: "8px",
      overflow: "hidden",
      marginRight: "0px",
      marginLeft: "0px",
      flex: "0 0 auto",
    };
    const ac_horizontal_separator2 = {
      height: "8px",
      overflow: "hidden",
      display: "flex",
      marginRight: "0px",
      marginLeft: "0px",
      flex: "0 0 auto",
    };
    const div_style = {
      display: "flex",
      flexDirection: "column",
      boxSizing: "border-box",
      flex: "0 0 auto",
    };
    const input_style = {
      flex: "1 1 auto",
      minWidth: "0px",
      borderRadius: "8px",
    };

    const ac_container = {
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-start",
      boxSizing: "border-box",
      flex: "0 0 auto",
      padding: "15px",
      margin: "0px",
    };

    const ac_columnset = {
      display: "flex",
      justifyContent: "flex-start",
      boxSizing: "border-box",
      flex: "0 0 auto",
      padding: "0px",
      margin: "0px",
    };

    return (
      <div aria-hidden="false" className="attachment">
        <div
          className="card"
          style={{ background: "rgb(233, 234, 234)", borderRadius: "25px" }}
        >
          <div className="ac-container" tabIndex={0} style={ac_container}>
            <div className="ac-columnSet" style={ac_columnset}>
              <div
                className="ac-container"
                style={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "flex-start",
                  boxSizing: "border-box",
                  minWidth: "0px",
                  flex: "1 1 100%",
                  padding: "0px",
                  margin: "0px",
                }}
              >
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>
                    Check-in Date
                    <span className="mandatory-field">*</span>
                  </p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <input
                      type="date"
                      name="indate"
                      min={new Date().toISOString().split("T")[0]}
                      max="undefined"
                      onChange={this.handleEvent}
                      className="ac-input ac-dateInput input-bot fontFamilyBot"
                      defaultValue={this.state.indate}
                      tabIndex={0}
                      style={{
                        width: "100%",
                        minWidth: "0px",
                        borderRadius: "8px",
                      }}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>
                    Tentative Check in Time
                    <span className="mandatory-field">*</span>
                  </p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <input
                      type="time"
                      name="intime"
                      onChange={this.handleEvent}
                      className="ac-input ac-textInput input-bot fontFamilyBot"
                      defaultValue={this.state.intime}
                      tabIndex={0}
                      style={input_style}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>
                    Expected No.of People (in digits)
                    <span className="mandatory-field">*</span>
                  </p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <input
                      type="number"
                      name="capacity"
                      onChange={this.handleEvent}
                      className="ac-input ac-textInput"
                      defaultValue={this.state.capacity}
                      tabIndex={0}
                      style={input_style}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div style={{ overflow: "hidden" }}>
                  <button
                    id="submitbutton"
                    aria-label="Submit Info"
                    type="button"
                    onClick={() => {
                      this.Submitinfo();
                    }}
                    className="submitbtn follow"
                  >
                    Submit
                  </button>

                  <button
                    id="menubutton"
                    aria-label="Main Menu"
                    type="button"
                    onClick={() => this.showMenu()}
                    className="submitbtn follow"
                  >
                    Back to Menu
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default VenueForm;
