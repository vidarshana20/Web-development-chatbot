import React from "react";
import "../styles/custom.css";

class OtherForm extends React.Component {
  constructor(props) {
    super(props);

    //console.log("calling otherform ", props);

    var name = props.step.component._owner.memoizedState.name;
    var email = props.step.component._owner.memoizedState.email;
    var phone = props.step.component._owner.memoizedState.phone;
    var city = props.step.component._owner.memoizedState.city;
    var msg = props.step.component._owner.memoizedState.msg;
    var action = props.step.component._owner.memoizedState.action;
    var hotel = props.step.component._owner.memoizedState.hotel;

    if (props.data) {
      action = props.data.action;
    }

    this.state = {
      name: name,
      email: email,
      phone: phone,
      action: action,
      city: city,
      msg: msg,
      hotel: hotel,
    };
    this.handleEvent = this.handleEvent.bind(this);

    //console.log("Other Form Data", this.state);
  }

  handleEvent(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  validateNumber(input) {
    const num = input && input.trim();
    var re = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[56789]\d{9}$/;
    return re.test(num)
      ? {
          success: true,
          num: num,
        }
      : {
          success: false,
          message: `${input} doesn't seem to be a valid Indian mobile number. Try Again and Submit(No Spaces)`,
        };
  }

  Submitinfo() {
    let result,
      flag = true;
    if (!this.state.name) {
      alert("Name cannot be empty. Try again and Submit");
      flag = false;
    }

    if (!this.state.phone) {
      alert("Phone number cannot be empty. Try again and Submit");
      flag = false;
    }

    if (!this.state.msg) {
      alert("Details cannot be empty. Try again and Submit");
      flag = false;
    }

    if (flag) {
      if (this.state.phone) result = this.validateNumber(this.state.phone);
      if (result.success) {
        this.setState({ trigger: true }, () => {
          if (
            this.state.action === "General Enquiry" &&
            [
              "Tuskers Hill"
            ].includes(this.state.hotel)
          ) {
            this.props.triggerNextStep({
              trigger: "confirm-faq-details",
              value: this.state,
            });
          } else {
            this.props.triggerNextStep({
              trigger: "confirm-other-details",
              value: this.state,
            });
          }
        });
      } else {
        if (this.state.phone && result.message) alert(result.message);
      }
    }
  }

  showMenu() {
    this.setState({ trigger: true }, () => {
      this.props.triggerNextStep({
        trigger: "mainmenu",
        value: this.state,
      });
    });
  }

  render() {
    //console.log("Contact Form - Props: ", this.props);

    const ac_textblock = {
      overflow: "hidden",
      fontFamily: "Helvetica, sans-serif",
      fontSize: "14px",
      color: "rgba(51, 51, 51, 0.933)",
      fontWeight: 400,
      textAlign: "left",
      lineHeight: "18.62px",
      overflowWrap: "break-word",
      boxSizing: "border-box",
      flex: "0 0 auto",
    };
    const p_style = { marginTop: "0px", width: "100%", marginBottom: "0px" };
    const ac_horizontal_separator = {
      height: "8px",
      overflow: "hidden",
      marginRight: "0px",
      marginLeft: "0px",
      flex: "0 0 auto",
    };
    const ac_horizontal_separator2 = {
      height: "8px",
      overflow: "hidden",
      display: "flex",
      marginRight: "0px",
      marginLeft: "0px",
      flex: "0 0 auto",
    };
    const div_style = {
      display: "flex",
      flexDirection: "column",
      boxSizing: "border-box",
      flex: "0 0 auto",
    };
    const input_style = {
      flex: "1 1 auto",
      minWidth: "0px",
      borderRadius: "8px",
    };

    return (
      <div aria-hidden="false" className="attachment">
        <div
          className="card"
          style={{ background: "rgb(233, 234, 234)", borderRadius: "25px" }}
        >
          <div
            className="ac-container"
            tabIndex={0}
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
              boxSizing: "border-box",
              flex: "0 0 auto",
              padding: "15px",
              margin: "0px",
            }}
          >
            <div
              className="ac-columnSet"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                boxSizing: "border-box",
                flex: "0 0 auto",
                padding: "0px",
                margin: "0px",
              }}
            >
              <div
                className="ac-container"
                style={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "flex-start",
                  boxSizing: "border-box",
                  minWidth: "0px",
                  flex: "1 1 100%",
                  padding: "0px",
                  margin: "0px",
                }}
              >
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>Kindly Enter your details.</p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>
                    Name<span className="mandatory-field">*</span>
                  </p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <input
                      type="text"
                      name="name"
                      onChange={this.handleEvent}
                      className="ac-input ac-textInput"
                      defaultValue={this.state.name}
                      tabIndex={0}
                      style={input_style}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>
                    Phone Number<span className="mandatory-field">*</span>
                  </p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <input
                      type="text"
                      name="phone"
                      onChange={this.handleEvent}
                      className="ac-input ac-textInput"
                      defaultValue={this.state.phone}
                      tabIndex={0}
                      style={input_style}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>Email</p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <input
                      type="text"
                      name="email"
                      onChange={this.handleEvent}
                      className="ac-input ac-textInput"
                      defaultValue={this.state.email}
                      tabIndex={0}
                      style={input_style}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div className="ac-textBlock" style={ac_textblock}>
                  <p style={p_style}>City</p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <input
                      type="text"
                      name="city"
                      onChange={this.handleEvent}
                      className="ac-input ac-textInput"
                      defaultValue={this.state.city}
                      tabIndex={0}
                      style={input_style}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div
                  className="ac-textBlock fontFamilyBot"
                  style={ac_textblock}
                >
                  <p style={p_style}>
                    Details<span className="mandatory-field">*</span>
                  </p>
                </div>
                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator2}
                />
                <div style={div_style}>
                  <div
                    className="ac-input-container"
                    style={{ display: "flex" }}
                  >
                    <textarea
                      type="text"
                      name="msg"
                      onChange={this.handleEvent}
                      className="ac-input ac-textInput input-bot"
                      defaultValue={this.state.msg}
                      tabIndex={0}
                      style={input_style}
                    />
                  </div>
                </div>

                <div
                  className="ac-horizontal-separator"
                  style={ac_horizontal_separator}
                />
                <div style={{ overflow: "hidden" }}>
                  <button
                    id="submitbutton"
                    aria-label="Submit Info"
                    type="button"
                    onClick={() => {
                      this.Submitinfo();
                    }}
                    className="submitbtn follow"
                  >
                    Submit
                  </button>

                  <button
                    id="menubutton"
                    aria-label="Main Menu"
                    type="button"
                    onClick={() => this.showMenu()}
                    className="submitbtn follow"
                  >
                    Back to Menu
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default OtherForm;
