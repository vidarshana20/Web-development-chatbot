import React from "react";

export default class CompMsg extends React.Component {
  constructor(props) {
    //console.log("YKJ");
    super(props);
    this.state = { hotel: props.hotel };
    //console.log(props);
  }
  componentDidMount() {
    //console.log("YIOIJKJ");
    this.setState({ trigger: true }, () => {
      this.props.triggerNextStep({
        trigger: "showSelectMsg",
        value: this.state,
      });
    });
  }

  render() {
    //console.log("Props in contact:", this.props);
    return (
      <div
        className="card-bot-text text-sm-center-bot text-muted-bot fontFamilyBot"
        //style={{ fontSize: ".9rem", padding: "0px" }}
      >
        You have selected {this.state.hotel}, {this.props.steps.name.value}
      </div>
    );
  }
}
