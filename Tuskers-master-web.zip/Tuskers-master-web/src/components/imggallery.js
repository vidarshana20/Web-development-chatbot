import React from "react";
import Slider from "react-slick";
//import PropTypes from "prop-types";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "../styles/custom.css";

import HotelData from "../data/hotels.json";

class ImgCarousel extends React.Component {
  constructor(props) {
    //console.log("Img Carousel Props", props);
    super(props);
    this.state = {
      city: "Anaikatti",
      hotel: "Tuskers Hill",
    };
  }

  render() {
    //console.log("Image Carousel value:", this.state.opt);

    //this.props.getCurrent(this.state.opt);
    const element = HotelData[this.state.city][this.state.hotel];
    //console.log("Element", element);

    let settings = {
      infinite: false,
      speed: 500,
      arrows: true,
      slidesToShow: 1,
      slidesToScroll: 1,

      responsive: [
        {
          breakpoint: 960,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    };

    return (
      <div className="container-bot-carousel1 fontFamilyBot">
        {element.length === 0 ? (
          <div className="spinner-border fontFamilyBot" role="status">
            <span className="sr-only fontFamilyBot">Loading...</span>
          </div>
        ) : (
          <Slider {...settings}>
            {element.imgs.map((current) => (
              <div className="out" key={current.split(".")[0]}>
                <div
                  className="card-bot card-bot-carousel"
                  style={{ paddingRight: "0%" }}
                >
                  <a
                    href={`${element.imgpath}/${current}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <img
                      className="rounded-bot"
                      alt={""}
                      src={`${element.imgpath}/${current}`}
                      height={220}
                      width={220}
                    />
                  </a>
                </div>
              </div>
            ))}
          </Slider>
        )}
      </div>
    );
  }
}

export default ImgCarousel;
