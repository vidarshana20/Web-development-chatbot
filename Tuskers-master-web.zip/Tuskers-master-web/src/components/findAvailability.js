import React from "react";
import request from "request";
import "../styles/custom.css";
import roomData from "../data/rooms.json";
import ReactGA from "react-ga";

export default class FAQ extends React.Component {
  constructor(props) {
    super(props);
    //console.log("FAQ Constructor: ", props);

    var indate = props.step.component._owner.memoizedState.indate;
    var outdate = props.step.component._owner.memoizedState.outdate;
    var hotel = props.step.component._owner.memoizedState.hotel;
    var venue = props.step.component._owner.memoizedState.venue;

    this.state = {
      loading: true,
      status: "",
      rate: "",
      indate: indate,
      outdate: outdate,
      hotel: hotel,
      venue: venue,
    };

    //console.log("Availability State: ", this.state);
  }

  async sendRequest(url, payload) {
    return new Promise(function(resolve, reject) {
      request.get({ url: url, qs: payload }, function(error, response, body) {
        if (!error && response.statusCode === 200) {
          //console.log("Success: ");

          resolve(JSON.parse(body));
        } else {
          //console.log("ERROR:", error);
          reject(error);
        }
      });
    });
  }

  async componentDidMount() {
    ReactGA.pageview("Find Room Availability");
    this.setState({
      loading: true,
    });

    /*
    var d1 = this.state.indate.split("-");
    var d2 = this.state.outdate.split("-");

    var date1 = d1[2] + "-" + d1[1] + "-" + d1[0];
    var date2 = d2[2] + "-" + d2[1] + "-" + d2[0];
*/
    //console.log("Date1:", this.state.indate);

    var data = roomData[this.state.hotel].filter(
      (x) => x.title === this.state.venue
    );

    //console.log("Data ", data[0]);
    var hotelcode = data[0]["hotel_code"];
    var invcode = data[0]["room_code"];
    var ratecode = data[0]["cp_rate_plan_code"];
    //console.log("Codes:", hotelcode, " ", invcode, " ", ratecode);

    var url = `https://cors-anywhere.herokuapp.com/https://cm.resavenue.com/channelcontroller/PropertyDetails`;

    var payload = {
      password: "poppy!@#19",
      username: "bookings@poppyshotels.com",
      id_context: "POPPY",
      start: this.state.indate,
      end: this.state.outdate,
      hotel_code: hotelcode,
      invCode: invcode,
      response_type: "json",
      request_method: "inventory",
    };

    var out = await this.sendRequest(url, payload);

    var avail = parseInt(
      out["OTA_HotelInventoryRS"]["Inventories"][0]["Inventory"][0]["InvCount"]
    );

    //console.log("Availability: ", avail);

    if (avail === 0) {
      this.setState({ loading: false, status: false });
    } else {
      //console.log("In Here second");
      var url2 =
        "https://cors-anywhere.herokuapp.com/https://cm.resavenue.com/channelcontroller/PropertyDetails";

      var payload2 = {
        password: "poppy!@#19",
        username: "bookings@poppyshotels.com",
        id_context: "POPPY",
        start: this.state.indate,
        end: this.state.outdate,
        hotel_code: hotelcode,
        rateCode: ratecode,
        response_type: "json",
        request_method: "rate",
      };

      var out2 = await this.sendRequest(url2, payload2);

      //console.log("Out2:", out2);

      var rate = out2["OTA_HotelRateRS"]["Rates"][0]["Rate"][0]["Single"];
      this.setState({ loading: false, status: true, rate: rate });
    }
  }

  triggerNext(val) {
    this.setState({ trigger: true }, () => {
      this.props.triggerNextStep({
        trigger: val,
        value: this.state,
      });
    });
  }

  render() {
    let output;

    if (this.state.loading === false) {
      if (this.state.status) {
        output =
          "We have rooms available on your chosen dates starting from Rs." +
          this.state.rate +
          " per room. Would you like to submit your details for Booking?";

        return (
          <div className="fontFamilyBot" style={{ fontSize: ".9rem" }}>
            {output}
            <div
              className="ac-horizontal-separator"
              style={{ height: "8px", overflow: "hidden" }}
            />
            <div>
              <div style={{ overflow: "hidden" }}>
                <button
                  id="menubutton"
                  aria-label="Main Menu"
                  type="button"
                  onClick={() => this.triggerNext("mainmenu")}
                  className="submitbtn follow"
                >
                  Back to Menu
                </button>

                <button
                  id="submitbutton"
                  aria-label="Main Menu"
                  type="button"
                  onClick={() => this.triggerNext("get-contactform")}
                  className="submitbtn follow"
                >
                  Proceed
                </button>
              </div>
              <div />
            </div>
          </div>
        );
      } else {
        output =
          "Sorry, we do not have any availability on the dates you selected. Would you like to choose different dates?";

        return (
          <div className="fontFamilyBot" style={{ fontSize: ".9rem" }}>
            {output}
            <div
              className="ac-horizontal-separator"
              style={{ height: "8px", overflow: "hidden" }}
            />
            <div>
              <div style={{ overflow: "hidden" }}>
                <button
                  id="submitbutton"
                  aria-label="Main Menu"
                  type="button"
                  onClick={() => this.triggerNext("Modify-Booking")}
                  className="submitbtn follow"
                >
                  Change Dates
                </button>

                <button
                  id="menubutton"
                  aria-label="Main Menu"
                  type="button"
                  onClick={() => this.triggerNext("mainmenu")}
                  className="submitbtn follow"
                >
                  Back to Menu
                </button>
              </div>
              <div />
            </div>
          </div>
        );
      }
    } else
      return (
        <div className="card-bot-text text-sm-center-bot text-muted-bot fontFamilyBot">
          Please wait while I check for the availability.This might take a
          minute..
        </div>
      );
  }
}
