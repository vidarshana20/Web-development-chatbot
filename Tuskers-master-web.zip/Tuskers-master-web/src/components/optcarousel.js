import React from "react";
import Controller from "./controller";
import Contact from "./contacts";
import "../styles/custom.css";

import menuData from "../data/options.json";
import ReactGA from "react-ga";

class OptCarousel extends React.Component {
  constructor(props) {
    //console.log("OptCarousel Opt", props.option);
    super(props);

    this.state = {
      hotel: props.step.component._owner.memoizedState.hotel,
      opt: props.step.component._owner.memoizedState.hotel,
      action: "",
    };

    //console.log("OptCarousel Props", props);

    this.triggerNext = this.triggerNext.bind(this);
  }

  triggerNext(val) {
    //console.log("OptCarousal setval: ", val);
    this.setState({ opt: val });

    switch (val) {
      case "Room Booking":
      case "Package Enquiry":
      case "General Enquiry":
      case "Submit Feedback":
      case "Register Complaint":
      case "Dining":
      case "Facilities":
      case "Wellness":
      case "Banquet":
        ReactGA.pageview(val);
        this.setState({ action: val });
        break;

      
    }
  }

  render() {
    //console.log("Carousel value:", this.state.opt);
console.log(this.state)
   
    if (
      [
        "Room Booking",
        "Package Enquiry",
        "General Enquiry",
        "Submit Feedback",
        "Register Complaint",
        "Dining",
        "Facilities",
        "Wellness",
        "Banquet",
      ].includes(this.state.opt)
    ) {
      return <Controller {...this.props} action={this.state.action} />;
    } else if (this.state.opt === "Contact Us") {
      ReactGA.pageview("Contact Info");
      return <Contact {...this.props} hotel={this.state.hotel} />;
    } else {
      var buttons = menuData[this.state.opt].value;

      return (
        <div>
        <p className="card-bot-text text-sm-center-bot text-muted-bot fontFamilyBot">
        What would you like to do or know about?
      </p>
          <ul className="sc-ifAKCX gkhNlr rsc-os-options" >
            {buttons.map((x) => {
              return (
                <li
                  className="sc-htpNat GgOGn rsc-os-option" 
                  key={x.split(".")[0]}
                >
                  <button
                    className="sc-bxivhb fRDDYO rsc-os-option-element" id="butt"
                    onClick={() => this.triggerNext(x)}
                  >
                    {x}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      );
    }
  }
}

export default OptCarousel;
