import React from "react";
import request from "request";
import "../styles/custom.css";
import Answers from "../data/faq.json";
import sendMail from "../mailview";
import ReactGA from "react-ga";

export default class FAQ extends React.Component {
  constructor(props) {
    super(props);
    //console.log("FAQ Constructor: ", props);

    var question = props.step.component._owner.memoizedState.msg;
    var phone = props.step.component._owner.memoizedState.phone;
    var hotel = props.step.component._owner.memoizedState.hotel;

    this.count = 0;
    this.state = {
      loading: true,
      responseData: "",
      status: "Unanswered",
      answer: "",
      question: question,
      phone: phone,
      hotel: hotel,
    };
  }

  async componentDidMount() {
    ReactGA.pageview("FAQ");
    this.setState({
      loading: true,
      msg: this.state.question,
      phone: this.state.phone,
    });
    var headers = {
      Authorization: "Bearer YISLBSCABQR7PK7RCFJDYGPSDCWF2FXG",
    };

    var options = {
      url: "https://api.wit.ai/message?v=20200203&q=" + this.state.question,
      headers: headers,
    };

    var out = await new Promise(function(resolve, reject) {
      request(options, function(error, response, body) {
        if (!error && response.statusCode === 200) {
          //console.log("Success: ");
          resolve(JSON.parse(body));
        } else {
          //console.log("ERROR:", error);
          reject(error);
        }
      });
    });

    this.setState({ loading: false, responseData: out });
  }

  showMenu(reply, status) {
    this.setState({ trigger: true, status: status, answer: reply }, () => {
      this.props.triggerNextStep({
        trigger: "12",
        value: this.state,
      });
    });
  }

  sendData(ans, status) {
    //console.log("count: ", this.count);
    if (this.count === 0) {
      //console.log("Calling sendData: ", ans, status);
      var googleSheetLink = process.env.REACT_APP_SHEETLINK;

      var date = new Date()
        .toLocaleString({ timeZone: "Asia/Kolkata" })
        .slice(0, 10)
        .replace(",", "");
      var time = new Date()
        .toLocaleString({ timeZone: "Asia/Kolkata" })
        .slice(10)
        .replace(",", "");

      var tempdate =
        date.split("/")[1] +
        "-" +
        date.split("/")[0] +
        "-" +
        date.split("/")[2];

      var data = {
        name: this.props.step.component._owner.memoizedState.name,
        phone: this.state.phone,
        email: this.props.step.component._owner.memoizedState.email,
        msg: this.props.step.component._owner.memoizedState.msg,
        city: this.props.step.component._owner.memoizedState.city,
        hotel: this.props.step.component._owner.memoizedState.hotel,
        status: status,
        reply: ans,
        date: tempdate,
        time: time,
        action: "General Enquiry",
      };

      //console.log("FAQ Mail: ", data);

      request.get(
        googleSheetLink +
          "Name=" +
          data.name +
          "&Phone=" +
          data.phone +
          "&Property=" +
          data.hotel +
          "&Email=" +
          data.email +
          "&City=" +
          data.city +
          "&Question=" +
          data.msg +
          "&Status=" +
          data.status +
          "&Response=" +
          data.reply +
          "&Message Date=" +
          data.date +
          "&Message Time=" +
          data.time +
          "&sheetName=Enquiry"
      );

      sendMail({ ...data });
      this.count = 1;
    }
  }

  render() {
    let ans;
    let status;
    if (!this.state.loading) {
      //console.log("Return: ", this.state.responseData);
      //console.log("Response: ", this.state.responseData.entities);
      var len = Object.keys(this.state.responseData["entities"]).length;
      //console.log("Length: ", len);
      if (len > 0) {
        var key = Object.keys(this.state.responseData["entities"])[0];
        ans = Answers[key][this.state.hotel];
        status = "Answered";

        this.sendData(ans, status);

        //console.log("Answer: ", ans);

        return (
          <div className="fontFamilyBot" style={{ fontSize: ".9rem" }}>
            {ans}
            <div
              className="ac-horizontal-separator"
              style={{ height: "8px", overflow: "hidden" }}
            />
            <div>
              <div style={{ overflow: "hidden" }}>
                <button
                  id="menubutton"
                  aria-label="Main Menu"
                  type="button"
                  onClick={() => this.showMenu(ans, status)}
                  className="submitbtn follow"
                >
                  Back to Menu
                </button>
              </div>
              <div />
            </div>
          </div>
        );
      } else {
        ans =
          "I am unable to give you an answer at the moment, but I have forwarded your question to the concerned executive. They will contact you shortly at " +
          this.state.phone;
        status = "Unanswered";
        this.sendData(ans, status);
        return (
          <div className="fontFamilyBot" style={{ fontSize: ".9rem" }}>
            {ans}
            <div
              className="ac-horizontal-separator"
              style={{ height: "8px", overflow: "hidden" }}
            />
            <div>
              <div style={{ overflow: "hidden" }}>
                <button
                  id="menubutton"
                  aria-label="Main Menu"
                  type="button"
                  onClick={() => this.showMenu(ans, status)}
                  className="submitbtn follow"
                >
                  Back to Menu
                </button>
              </div>
              <div />
            </div>
          </div>
        );
      }
    } else
      return (
        <div className="card-bot-text text-sm-center-bot text-muted-bot fontFamilyBot">
          Getting your answer...
        </div>
      );
  }
}
