import React from "react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "../styles/custom.css";

import roomData from "../data/rooms.json";
import banquetData from "../data/banquet.json";
import diningData from "../data/dining.json";
import facilitiesData from "../data/facilities.json";
import BookingForm from "../forms/bookingform";
import VenueForm from "../forms/venueform";
import Slider from "react-slick";
import ReactGA from "react-ga";

class ImgCarousel extends React.Component {
  constructor(props) {
    //console.log("Img Carousel Props", props);
    super(props);
    this.state = {
      opt: props.option,
      hotel: props.step.component._owner.memoizedState.hotel,
      venue: "",
      action: props.action,
    };

    this.triggerNext = this.triggerNext.bind(this);
  }

  showHotels(val) {}

  triggerNext(val) {
    //console.log("Img Carousal setval: ", val);
    this.setState({ opt: val });

    switch (val) {
      case "The White Elephant":
      case "Tuskers Cottage":
      case "Tuskers Club":
      case "Tuskers Pool Villa":
        ReactGA.pageview(val);
        this.setState({ venue: val });
        break;

      case "Back to Menu":
      case "Main Menu":
        this.setState({ trigger: true }, () => {
          this.props.triggerNextStep({
            trigger: "mainmenu",
            value: this.state,
          });
        });
        break;
      default:
        break;
    }
  }

  render() {
    //console.log("Image Carousel value:", this.state.opt);
    //console.log("Image Carousel state:", this.state);

    var venueOpts = [
      "The White Elephant",
      "The Lawn",
      "The Gaja Hall"
      
    ];

    var roomOpts = [
      "Tuskers Cottage",
      "Tuskers Club",
      "Tuskers Pool Villa"
    ];

    if (roomOpts.includes(this.state.opt)) {
      return (
        <BookingForm
          {...this.props}
          data={{ action: this.state.action, venue: this.state.venue }}
        />
      );
    } else if (venueOpts.includes(this.state.opt)) {
      return (
        <VenueForm
          {...this.props}
          data={{ action: this.state.action, venue: this.state.venue }}
        />
      );
    } else if (["Back to Menu", "Main Menu"].includes(this.state.opt)) {
      return (
        <div className="card-bot-text text-sm-center-bot text-muted-bot fontFamilyBot">
          Please wait while I take you back to the menu
        </div>
      );
    }

    //this.props.getCurrent(this.state.opt);
    //console.log("Element", element);
    else if (
      ["Room Booking", "Dining","Facilities", "Banquet"].includes(
        this.state.opt
      )
    ) {
      let element;

      if (this.state.opt === "Room Booking")
        element = roomData[this.state.hotel];
      else if (["Dining"].includes(this.state.opt))
        element = diningData[this.state.hotel];
      else if (["Facilities"].includes(this.state.opt))
        element = facilitiesData[this.state.hotel];
      else element = banquetData[this.state.hotel];

      let settings = {
        infinite: false,
        speed: 500,
        arrows: true,
        slidesToShow: 1,
        slidesToScroll: 1,

        responsive: [
          {
            breakpoint: 960,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
            },
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
            },
          },
        ],
      };

      return (
        <div className="container-bot-carousel1 fontFamilyBot">
          {element.length === 0 ? (
            <div className="spinner-border fontFamilyBot" role="status">
              <span className="sr-only fontFamilyBot">Loading...</span>
            </div>
          ) : (
            <Slider {...settings}>
              {element.map((current) => (
                <div className="out" key={current.title}>
                  <div
                    className="card-bot card-bot-carousel"
                    style={{ paddingRight: "0%" }}
                  >
                    <a
                      href={current.img}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <img
                        className="rounded-bot"
                        alt={""}
                        src={current.img}
                        style={{ maxHeight: "220px", maxWidth: "220px" }}
                      />
                    </a>

                    <div className="card-bot-body fontFamilyBot">
                      <h5 className="card-bot-title fontFamilyBot">
                        {current.title}
                      </h5>
                      <small style={{ color: "gray" }}>{current.desc}</small>
                      <br />
                      {current.value.map((x) => {
                        return (
                          <button
                            className="btn btn-sm follow btn-primary"
                            key={x}
                            onClick={() => {
                              if (["Main Menu", "Back to Menu"].includes(x))
                                this.triggerNext(x);
                              else this.triggerNext(current.title);
                            }}
                          >
                            {x}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ))}
            </Slider>
          )}
        </div>
      );
    }
  }
}

export default ImgCarousel;
