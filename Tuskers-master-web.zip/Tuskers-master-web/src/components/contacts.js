import React from "react";
import data from "../data/contacts.json";

export default class Contacts extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hotel: props.hotel,
    };
  }
  componentDidMount() {
    this.setState({ trigger: true }, () => {
      this.props.triggerNextStep({ trigger: "cont-opts" });
    });
  }

  render() {
    //console.log("Props in contact:", this.props);

    var info = data[this.state.hotel];

    return (
      <div
        className="container-bot-bot fontFamilyBot fontFamilyBot newlines"
        style={{ fontSize: ".8rem", maxHeight: "180px", maxWidth: "80%" }}
      >
        Hey {this.props.steps.name.value}, You can get in touch with us at
        {"\n\n"}
        <a
          href="mailto:reservation.tuskershill@poppyshotels.com"
          target="_blank"
          rel="noopener noreferrer"
        >
          <img
            src={"https://bot.cheersbye.com/dist/email-icon.png"}
            alt="Mail Icon"
            style={{ height: "10%", float: "left" }}
          />
        </a>{" "}
        : {info["Email"]}
        {"\n\n"}
        <img
          src={"https://bot.cheersbye.com/dist/phone-icon.png"}
          alt="Call Icon"
          style={{ height: "10%", float: "left" }}
        />{" "}
        : {info["Phone"]}
        {"\n\n"}
        <img
          src={"https://bot.cheersbye.com/dist/map-icon.png"}
          alt="Call Icon"
          style={{ height: "8%", float: "left" }}
        />{" "}
        : {info["Address"]}
      </div>
    );
  }
}
