import React, { Component } from "react";
import ChatBot from "react-simple-chatbot";
import { ThemeProvider } from "styled-components";
import HotelData from "../data/hotels.json";
import OptionsCarousel from "./optcarousel";
import ImgSlider from "./imggallery";

import BookingForm from "../forms/bookingform";
import VenueForm from "../forms/venueform";
import OtherForm from "../forms/otherform";
import ContactForm from "../forms/contactform";
import menuData from "../data/options.json";
import FAQ from "./faq";
import FindAvailability from "./findAvailability";
import "../styles/custom.css";
import sendMail from "../mailview";

const request = require("request");

const theme = {
  background: "#f5f8fb",
  fontFamily: "Helvetica Neue",
  headerBgColor: "#ba2429",
  headerFontColor: "#fff",
  headerFontSize: "15px",
  botBubbleColor: "#ba2429",
  botFontColor: "#fff",
  userBubbleColor: "#ffc4d1",
  userFontColor: "#000",
};

export default class chatbot extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      action: "",
      email: "",
      phone: "",
      city: "",
      hotel_city: "",
      hotel: "",
      indate: "",
      intime: "",
      outdate: "",
      capacity: "",
      venue: "",
      msg: "",
      reply: "",
      status: "",
      norooms: "",
      adults: "",
      children: "",
    };
  }

  setValues = (data) => {
    var d = {};

    for (const i in data) {
      if (this.state.hasOwnProperty(i)) {
        d[i] = data[i];
      }
    }
    //console.log("d in setval: ", d);
    this.setState(d);
  };

  writeSheetData(data) {
    var msgdate = new Date()
      .toLocaleString({ timeZone: "Asia/Kolkata" })
      .slice(0, 10)
      .replace(",", "");
    var time = new Date()
      .toLocaleString({ timeZone: "Asia/Kolkata" })
      .slice(10)
      .replace(",", "");

    msgdate =
      msgdate.split("/")[1] +
      "-" +
      msgdate.split("/")[0] +
      "-" +
      msgdate.split("/")[2];
    //console.log(msgdate);

    data.time = time;
    data.date = msgdate;

    //console.log("DATA:", data);

    if (data.action === "General Enquiry") {
      data.status = "Unanswered";
      data.reply =
        "I am unable to give you an answer at the moment, but I have forwarded your question to the concerned executive. They will contact you shortly at " +
        data.phone;
    }

    sendMail({ ...data }); //send email

    var ind, oud;
    if (data.indate) {
      var t1 = data.indate.split("-");
      ind = t1[2] + "-" + t1[1] + "-" + t1[0];
    }

    if (data.outdate) {
      var t2 = data.outdate.split("-");
      oud = t2[2] + "-" + t2[1] + "-" + t2[0];
    }

    var googleSheetLink = process.env.REACT_APP_SHEETLINK;

    var acts = {
      "Room Booking": "Room Booking",
      Dining: "Dining",
      "Banquet": "Banquet",
      "Facilities":"Facilities",
      "Package Enquiry": "Packages",
      "Submit Feedback": "Feedback",
      "Register Complaint": "Complaint",
      "General Enquiry": "Enquiry",
    };

    var sheetname = acts[data.action];

    request.get(
      googleSheetLink +
        "Name=" +
        data.name +
        "&Phone=" +
        data.phone +
        "&Property=" +
        data.hotel +
        "&Room=" +
        data.venue +
        "&Venue=" +
        data.venue +
        "&No.of Rooms=" +
        data.norooms +
        "&Adults=" +
        data.adults +
        "&Children=" +
        data.children +
        "&Check-in Date=" +
        ind +
        "&Check-in Time=" +
        data.intime +
        "&Check-out Date=" +
        oud +
        "&Check-out Time=" +
        data.outtime +
        "&No.of Persons=" +
        data.capacity +
        "&City=" +
        data.city +
        "&Email=" +
        data.email +
        "&Details=" +
        data.msg +
        "&Question=" +
        data.msg +
        "&Status=" +
        data.status +
        "&Response=" +
        data.reply +
        "&Message Date=" +
        data.date +
        "&Message Time=" +
        data.time +
        "&sheetName=" +
        sheetname
    );
  }

  render() {
    return (
      <ThemeProvider theme={theme}>
        <ChatBot
          floating={true}
          botAvatar={"https://bot.cheersbye.com/dist/poppys/bot-logo.png"}
          userAvatar={"https://bot.cheersbye.com/dist/poppys/user-avatar.png"}
          steps={[
            {
              id: "1",
              message:
                "Hi, Welcome to Tuskers Hill Resort! The magical essence in the casual charm and endless options of fun. For toddlers to teens, parents to grandparents; there's something for sure for everyone to enjoy. 😃 I am your virtual assistant here to help you!",
              trigger: "2",
            },
            {
              id: "2",
              message: "Kindly enter your name.",
              trigger: "name",
            },
            {
              id: "name",
              user: true,
              validator: (value) => {
                if (!value) {
                  return `Name cannot be empty.`;
                }
                return true;
              },
              trigger: "3",
            },
            {
              id: "3",
              message: ({ previousValue, steps }) => {
                //console.log({ steps });
                this.setValues({ name: previousValue });
                this.setState({ hotel_city: "Anaikatti" ,hotel:"Tuskers Hill"});
                return `Thanks ${previousValue}!`;
              },
              trigger: "mainmenu",
            },
           
            {
              id: "mainmenu",
              component: <OptionsCarousel {...this.props} />,
              waitAction: true,
            },

            {
              id: "confirm-booking-details",

              message: ({ previousValue }) => {
                //console.log("Message: ", { previousValue });
                this.setValues(previousValue);

                var t1 = previousValue.indate.split("-");
                var temp1 = t1[2] + "-" + t1[1] + "-" + t1[0];

                var t2 = previousValue.outdate.split("-");
                var temp2 = t2[2] + "-" + t2[1] + "-" + t2[0];

                var st = `Confirm the details?\nRoom: ${previousValue.venue}\nCheck-in: ${temp1} \nCheck-out: ${temp2} \nNo.of Rooms: ${previousValue.norooms}\nPersons: ${previousValue.adults} Adults; ${previousValue.children} Kids`;
                return st;
              },
              trigger: "confirm-booking-submit",
            },

            {
              id: "confirm-booking-submit",
              options: [
                { value: "Main Menu", label: "Main Menu", trigger: "mainmenu" },

                {
                  value: "Modify",
                  label: "Modify",
                  trigger: "Modify-Booking",
                },
                {
                  value: "Yes",
                  label: "Yes",
                  trigger: () => {
                    var hotels = [
                      "Tuskers Hill by Poppys"
                    ];

                    if (
                      hotels.includes(this.state.hotel) ||
                      this.state.venue === "Tuskers Cottage" || this.state.venue === "Tuskers Club" ||this.state.venue === "Tuskers Pool Villa" 
                    )
                      return "get-contactform";
                    else return "getAvailability";
                  },
                },
              ],
            },
            {
              id: "Modify-Booking",
              component: <BookingForm {...this.props} />,
              waitAction: true,
            },
            {
              id: "getAvailability",
              component: <FindAvailability {...this.props} />,
              waitAction: true,
            },
            {
              id: "get-contactform",
              component: (
                <ContactForm
                  {...this.props}
                  data={{
                    action: this.state.action,
                  }}
                />
              ),
              waitAction: true,
            },

            {
              id: "confirm-contact-details",

              message: ({ previousValue }) => {
                if (!previousValue.city) previousValue.city = "";
                if (!previousValue.msg) previousValue.msg = "";
                if (!previousValue.email) previousValue.email = "";
                this.setValues(previousValue);
                //console.log("Message: ", { previousValue });
                //console.log("State Now: ", this.state);

                var st = `Confirm the details?\nName: ${previousValue.name} \nPhone: ${previousValue.phone} `;

                if (previousValue.email !== "")
                  st += `\nEmail: ${previousValue.email}`;
                if (previousValue.city !== "")
                  st += `\nCity: ${previousValue.city}`;
                if (previousValue.msg !== "")
                  st += `\nDetails: ${previousValue.msg}`;

                //console.log("Again, state: ", this.state);

                return st;
              },
              trigger: "confirm-contact-submit",
            },
            {
              id: "confirm-contact-submit",
              options: [
                { value: "Main Menu", label: "Main Menu", trigger: "mainmenu" },

                {
                  value: "Modify",
                  label: "Modify",
                  trigger: "Modify-ContactForm",
                },
                {
                  value: "Yes",
                  label: "Yes",
                  trigger: "15",
                },
              ],
            },
            {
              id: "Modify-ContactForm",
              component: (
                <ContactForm
                  {...this.props}
                  data={{
                    action: this.state.action,
                  }}
                />
              ),
              waitAction: true,
            },
            {
              id: "MenuOnly",
              options: [
                { value: "Main Menu", label: "Main Menu", trigger: "mainmenu" },
              ],
            },
            {
              id: "cont-opts",
              options: [
                { value: "Main Menu", label: "Main Menu", trigger: "mainmenu" },
              ],
            },
            {
              id: "15",
              message: () => {
                //console.log("Before Writing: ", this.state);
                this.writeSheetData(this.state);
                //this.sendSMS(out);
                //console.log("Action: ", this.state.action);
                if (this.state.action === "Submit Feedback")
                  return `Thank you ${this.state.name} for your valuable feedback. We really appreciate it. Visit us again 😊😊`;
                else if (this.state.action === "Register Complaint")
                  return `We are sorry for your experience 😔, ${this.state.name}. Our executive will look into the issue and contact you back soon at ${this.state.phone}.`;
                else if (this.state.action === "General Enquiry")
                  return `I am unable to give you an answer at the moment, but I have forwarded your question to the concerned executive. They will contact you shortly at ${this.state.phone}.`;
                else if(this.state.action === "Room Booking" || this.state.action === "Dining" || this.state.action === "Banquet" || this.state.action === "Package Enquiry")
                  return `Thank You ${this.state.name}, we have received your details. Our executive will get in touch with you shortly. 🙂`;
              },
              trigger: "MenuOnly",
            },

            {
              id: "confirm-venue-details",

              message: ({ previousValue }) => {
                //console.log("Message: ", { previousValue });
                this.setValues(previousValue);

                var t1 = previousValue.indate.split("-");
                var temp1 = t1[2] + "-" + t1[1] + "-" + t1[0];

                let intm;
                var itm = previousValue.intime.split(":");

                if (parseInt(itm[0]) >= 12) {
                  if (itm[0] !== "12") itm[0] = itm[0] - 12;
                  intm = itm[0] + ":" + itm[1] + " pm";
                } else {
                  intm = previousValue.intime + " am";
                }

                var st = `Confirm the details?\nCheck-in: ${temp1} ${intm}\nNo.of People: ${previousValue.capacity}`;
                if (previousValue.action !== "Package Enquiry")
                  st += `\nVenue: ${previousValue.venue}`;
                return st;
              },
              trigger: "confirm-venue-submit",
            },

            {
              id: "confirm-venue-submit",
              options: [
                { value: "Main Menu", label: "Main Menu", trigger: "mainmenu" },
                {
                  value: "Modify",
                  label: "Modify",
                  trigger: "Modify-Venue",
                },
                {
                  value: "Yes",
                  label: "Yes",
                  trigger: "get-contactform",
                },
              ],
            },
            {
              id: "Modify-Venue",
              component: <VenueForm {...this.props} />,
              waitAction: true,
            },
            {
              id: "confirm-other-details",

              message: ({ previousValue }) => {
                if (!previousValue.city) previousValue.city = "";
                if (!previousValue.email) previousValue.email = "";
                this.setValues(previousValue);
                //console.log("Message: ", { previousValue });

                var st = `Confirm the details?\nName: ${previousValue.name} \nPhone: ${previousValue.phone} `;

                if (previousValue.email !== "")
                  st += `\nEmail: ${previousValue.email}`;
                if (previousValue.city !== "")
                  st += `\nCity: ${previousValue.city}`;

                st += `\nDetails: ${previousValue.msg}`;

                return st;
              },
              trigger: "confirm-other-submit",
            },
            {
              id: "confirm-other-submit",
              options: [
                { value: "Main Menu", label: "Main Menu", trigger: "mainmenu" },
                {
                  value: "Modify",
                  label: "Modify",
                  trigger: "Modify-OtherForm",
                },
                {
                  value: "Yes",
                  label: "Yes",
                  trigger: "15",
                },
              ],
            },
            {
              id: "Modify-OtherForm",
              component: <OtherForm {...this.props} />,
              waitAction: true,
            },
            {
              id: "confirm-faq-details",

              message: ({ previousValue }) => {
                if (!previousValue.city) previousValue.city = "";
                if (!previousValue.email) previousValue.email = "";
                this.setValues(previousValue);
                //console.log("In confirm FAQ");

                var st = `Confirm the details?\nName: ${previousValue.name} \nPhone: ${previousValue.phone} `;

                if (previousValue.email !== "")
                  st += `\nEmail: ${previousValue.email}`;
                if (previousValue.city !== "")
                  st += `\nCity: ${previousValue.city}`;

                st += `\nEnquiry: ${previousValue.msg}`;

                return st;
              },
              trigger: "confirm-faq-submit",
            },
            {
              id: "confirm-faq-submit",
              options: [
                { value: "Main Menu", label: "Main Menu", trigger: "mainmenu" },
                {
                  value: "Modify",
                  label: "Modify",
                  trigger: "Modify-OtherForm",
                },
                {
                  value: "Yes",
                  label: "Yes",
                  trigger: "11",
                },
              ],
            },

            {
              id: "11",
              component: <FAQ {...this.props} />,
              waitAction: true,
            },
            {
              id: "12",
              message: (previousValue) => {
                this.setValues({
                  reply: previousValue.previousValue.answer,
                  status: previousValue.previousValue.status,
                });
                return (
                  "Thanks for contacting " +
                  this.state.hotel +"!"
                  
                );
              },

              trigger: "mainmenu",
            },

            {
              id: "wellness",
              component: (
                <div className="fontFamilyBot">
                  You can find more details at{" "}
                  <a
                    style={{ color: "white" }}
                    href="http://www.champaayurveda.com"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    www.champaayurveda.com
                  </a>
                </div>
              ),
              asMessage: true,
              trigger: "mainmenu",
            },
          ]}
        />
      </ThemeProvider>
    );
  }
}
