import React from "react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "../styles/custom.css";
import wellnessData from "../data/wellness.json";
import Slider from "react-slick";

export default class ImgCarousel extends React.Component {
  constructor(props) {
    //console.log("Wellness props:", props);
    super(props);
    this.state = { hotel: props.step.component._owner.memoizedState.hotel };
    //console.log("Wellness Hotel: ", this.state.hotel);
  }

  componentDidMount() {
    //console.log("YIOIJKJ");
    this.setState({ trigger: true }, () => {
      this.props.triggerNextStep({
        trigger: "wellness",
        value: this.state,
      });
    });
  }

  render() {
    //this.props.getCurrent(this.state.opt);
    const element = wellnessData[this.state.hotel];
    //console.log("Element", element);

    let settings = {
      infinite: false,
      speed: 500,
      arrows: true,
      slidesToShow: 1,
      slidesToScroll: 1,

      responsive: [
        {
          breakpoint: 960,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    };

    return (
      <div className="container-bot-carousel1 fontFamilyBot">
        {element.length === 0 ? (
          <div className="spinner-border fontFamilyBot" role="status">
            <span className="sr-only fontFamilyBot">Loading...</span>
          </div>
        ) : (
          <Slider {...settings}>
            {element.map((current) => (
              <div className="out" key={current.title}>
                <div
                  className="card-bot card-bot-carousel"
                  style={{ paddingRight: "0%" }}
                >
                  <a
                    href={current.img}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <img
                      className="rounded-bot"
                      alt={""}
                      src={current.img}
                      height={220}
                      width={220}
                    />
                  </a>

                  <div className="card-bot-body fontFamilyBot">
                    <h5 className="card-bot-title fontFamilyBot">
                      {current.title}
                    </h5>
                    <small style={{ color: "gray" }}>{current.desc}</small>
                    <br />
                  </div>
                </div>
              </div>
            ))}
          </Slider>
        )}
      </div>
    );
  }
}
