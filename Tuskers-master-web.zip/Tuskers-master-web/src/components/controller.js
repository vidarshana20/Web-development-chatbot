import React from "react";
import "../styles/custom.css";

import ImgCarousel from "./imgcarousel";
import VenueForm from "../forms/venueform";
import OtherForm from "../forms/otherform";
import Wellness from "./wellness";

class Controller extends React.Component {
  constructor(props) {
    //console.log("Controller Props", props);
    super(props);

    var action = "";

    if (props.action) {
      action = props.action;
    }

    this.state = {
      action: action,
    };
    //this.triggerNext = this.triggerNext.bind(this);
  }

  render() {
    //console.log("Controller: ", this.state.action);
    if (
      ["Room Booking", "Banquet", "Dining","Facilities"].includes(
        this.state.action
      )
    )
      return <ImgCarousel {...this.props} option={this.state.action} />;
    else if (this.state.action === "Package Enquiry")
      return (
        <VenueForm
          {...this.props}
          data={{ venue: "", action: "Package Enquiry" }}
        />
      );
    else if (
      ["Submit Feedback", "Register Complaint", "General Enquiry"].includes(
        this.state.action
      )
    )
      return <OtherForm {...this.props} data={{ action: this.state.action }} />;
    else if (this.state.action === "Wellness")
      return <Wellness {...this.props} />;
  }
}

export default Controller;
