import React from "react";
import { useState } from "react";
import ReactGA from "react-ga";

import Chatbot from "./components/chatbot";

function App() {
  const [isAnalyticsSent, SetIsAnalyticsSent] = useState(false);
  window.onload = function() {
    var InitBotAnalytics = document.querySelector(".rsc-float-button");
    if (isAnalyticsSent == false) {
      InitBotAnalytics.addEventListener("click", function() {
        ReactGA.initialize(process.env.REACT_APP_GA_TAG);
        ReactGA.pageview("/BotHome");
        SetIsAnalyticsSent(true);
      });
    }
  };

  return (
    <div className="App">
      <Chatbot />
    </div>
  );
}

export default App;
