import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
//import * as serviceWorker from "./serviceWorker";

ReactDOM.render(<App />, document.getElementById("tuskers-root"));

function tuskersBrand() {
  return (
    <div>
      <a
        href="https://cheersbye.com/chatbot"
        target="_blank"
        rel="noreferrer noopener"
      >
        <img
          alt="CheersBye Logo"
          className="brandlogo"
          src="https://bot.cheersbye.com/dist/poweredby.png"
        />
      </a>
    </div>
  );
}

function tuskersBrandTimer() {
  document
    .getElementsByClassName("rsc-container")[0]
    .setAttribute("id", "tuskers-brandClass");
  var node = document.createElement("div");
  node.id = "tuskers-rsc-brand-container";
  document.getElementById("tuskers-brandClass").appendChild(node);
  ReactDOM.render(
    <tuskersBrand />,
    document.getElementById("tuskers-rsc-brand-container")
  );
}

setTimeout(function() {
  tuskersBrandTimer();
}, 2000);

function PopupComp() {
  return (
    <div className="popup-card-bot">
      <div className="popup-container-bot">
        <p style={{ margin: "10px 0 10px" }}>
          Hi! Welcome to Tuskers Hill Resort. Click the icon below for more
          assistance.
        </p>
      </div>
    </div>
  );
}

function PopUpTimer() {
  var div = document.createElement("div");
  div.id = "popupid";
  document.body.appendChild(div);
  ReactDOM.render(<PopupComp />, document.getElementById("popupid"));
}

function HidePopup() {
  document.getElementById("popupid").style.display = "none";
}

setTimeout(function() {
  PopUpTimer();
}, 500);

setTimeout(function() {
  HidePopup();
}, 5000);

var botPopupButton = document.getElementsByClassName("rsc-float-button");
botPopupButton[0].onclick = function() {
  document.getElementById("popupid").style.display = "none";
};
